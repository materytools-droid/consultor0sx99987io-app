import uvicorn
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
import webview
import threading

app = FastAPI()

# Código HTML incrustado directamente para evitar problemas de rutas en Windows
HTML_CONTENT = """<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consultorio Médico - Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-900 text-gray-100 flex flex-col h-screen overflow-hidden">

    <!-- BARRA DE NAVEGACIÓN SUPERIOR -->
    <header class="bg-gray-800 border-b border-gray-700 h-16 flex items-center justify-between px-6 z-40 relative">
        <div class="flex items-center gap-3">
            <span class="text-xl font-bold text-red-500 tracking-wider">🏥 CONSULTORIO IA</span>
        </div>
        
        <nav class="hidden md:flex items-center gap-6 text-sm font-medium text-gray-300">
            <a href="javascript:void(0);" onclick="cambiarSeccion('dashboard')" class="hover:text-red-400 transition nav-link text-red-400" data-target="dashboard">Inicio</a>
            <a href="javascript:void(0);" onclick="cambiarSeccion('pacientes')" class="hover:text-red-400 transition nav-link" data-target="pacientes">Pacientes</a>
            <a href="javascript:void(0);" onclick="cambiarSeccion('agenda')" class="hover:text-red-400 transition nav-link" data-target="agenda">Agenda</a>
            <a href="javascript:void(0);" onclick="cambiarSeccion('farmacia')" class="hover:text-red-400 transition nav-link" data-target="farmacia">Precios</a>
            <a href="javascript:void(0);" onclick="cambiarSeccion('vademecum')" class="hover:text-red-400 transition nav-link" data-target="vademecum">Vademécum</a>
            <a href="javascript:void(0);" onclick="cambiarSeccion('config')" class="hover:text-red-400 transition nav-link" data-target="config">Configuración</a>
        </nav>

        <div class="flex items-center gap-4">
            <span class="text-xs text-red-400 font-medium bg-red-950/50 border border-red-800/50 px-3 py-1 rounded-full hidden sm:inline-block">● Servidor Activo</span>
            
            <!-- ICONO DE PERFIL CON MENÚ DESPLEGABLE -->
            <div class="relative group">
                <button class="flex items-center gap-2 bg-gray-700 hover:bg-gray-600 px-3 py-1.5 rounded-lg text-sm text-white transition cursor-pointer">
                    <div id="user-avatar" class="w-7 h-7 bg-red-600 rounded-full flex items-center justify-center font-bold text-xs text-white">A</div>
                    <span id="user-display-name" class="font-medium hidden sm:inline">Admin</span>
                    <svg class="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>
                </button>
                
                <div class="absolute right-0 mt-1 w-48 bg-gray-800 border border-gray-700 rounded-xl shadow-2xl py-2 hidden group-hover:block z-50">
                    <div class="px-4 py-2 border-b border-gray-700 text-xs text-gray-400 truncate" id="user-display-email">
                        materytools@gmail.com
                    </div>
                    <a href="javascript:void(0);" onclick="cambiarSeccion('config')" class="block px-4 py-2 text-sm text-gray-200 hover:bg-gray-700 transition">⚙️ Cambiar cuenta</a>
                    <a href="javascript:void(0);" onclick="cerrarSesionPerfil()" class="block px-4 py-2 text-sm text-red-400 hover:bg-gray-700 transition">🚪 Salir del perfil</a>
                </div>
            </div>

            <button onclick="toggleMobileMenu()" class="md:hidden text-gray-300 hover:text-white text-xl">☰</button>
        </div>
    </header>

    <!-- MENÚ MÓVIL DESPLEGABLE -->
    <div id="mobile-menu" class="hidden md:hidden bg-gray-800 border-b border-gray-700 px-6 py-4 space-y-3 z-30">
        <a href="javascript:void(0);" onclick="cambiarSeccion('dashboard'); toggleMobileMenu();" class="block text-gray-300 hover:text-red-400">Inicio</a>
        <a href="javascript:void(0);" onclick="cambiarSeccion('pacientes'); toggleMobileMenu();" class="block text-gray-300 hover:text-red-400">Pacientes</a>
        <a href="javascript:void(0);" onclick="cambiarSeccion('agenda'); toggleMobileMenu();" class="block text-gray-300 hover:text-red-400">Agenda</a>
        <a href="javascript:void(0);" onclick="cambiarSeccion('farmacia'); toggleMobileMenu();" class="block text-gray-300 hover:text-red-400">Precios</a>
        <a href="javascript:void(0);" onclick="cambiarSeccion('vademecum'); toggleMobileMenu();" class="block text-gray-300 hover:text-red-400">Vademécum</a>
        <a href="javascript:void(0);" onclick="cambiarSeccion('config'); toggleMobileMenu();" class="block text-gray-300 hover:text-red-400">Configuración</a>
    </div>

    <!-- CONTENIDO PRINCIPAL -->
    <main class="flex-1 flex flex-col overflow-y-auto">
        <div class="p-8 space-y-8">
            
            <!-- DASHBOARD / PORTAL INTERACTIVO -->
            <section id="sec-dashboard" class="seccion-contenido space-y-8">
                <!-- HERO BANNER -->
                <div class="relative rounded-2xl overflow-hidden shadow-2xl border border-gray-700 bg-cover bg-center" style="background-image: linear-gradient(rgba(17, 24, 39, 0.85), rgba(17, 24, 39, 0.90)), url('https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&w=1200&q=80');">
                    <div class="px-8 py-16 md:py-20 text-center max-w-3xl mx-auto space-y-6">
                        <span class="bg-red-600/20 text-red-400 border border-red-500/30 text-xs px-3 py-1 rounded-full uppercase tracking-widest font-semibold">Plataforma Médica Profesional</span>
                        <h2 class="text-3xl md:text-5xl font-extrabold text-white tracking-tight">Gestión Clínica y Farmacéutica Inteligente</h2>
                        <p class="text-gray-300 text-base md:text-lg leading-relaxed">Optimiza la atención de tus pacientes, consulta precios en tiempo real y accede al vademécum clínico con la máxima eficiencia y velocidad.</p>
                        <div class="pt-2 flex justify-center gap-4">
                            <button onclick="abrirModalPaciente()" class="bg-red-600 hover:bg-red-500 text-white font-medium px-6 py-3 rounded-xl shadow-lg transition cursor-pointer">+ Registrar Paciente</button>
                            <button onclick="cambiarSeccion('vademecum')" class="bg-gray-800 hover:bg-gray-700 border border-gray-600 text-white font-medium px-6 py-3 rounded-xl transition cursor-pointer">Consultar Vademécum</button>
                        </div>
                    </div>
                </div>

                <!-- Estadísticas rápidas -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div class="bg-gray-800 p-6 rounded-xl border border-gray-700 shadow-lg">
                        <p class="text-gray-400 text-sm">Pacientes en Espera</p>
                        <h3 class="text-3xl font-bold text-white mt-2" id="stat-espera">0</h3>
                    </div>
                    <div class="bg-gray-800 p-6 rounded-xl border border-gray-700 shadow-lg">
                        <p class="text-gray-400 text-sm">Pacientes Vistos</p>
                        <h3 class="text-3xl font-bold text-red-500 mt-2" id="stat-vistos">0</h3>
                    </div>
                    <div class="bg-gray-800 p-6 rounded-xl border border-gray-700 shadow-lg">
                        <p class="text-gray-400 text-sm">Estado de Farmacias Nuevo Siglo API</p>
                        <h3 class="text-3xl font-bold text-blue-400 mt-2">En Línea</h3>
                    </div>
                </div>
            </section>

            <!-- AGENDA -->
            <section id="sec-agenda" class="seccion-contenido hidden space-y-6">
                <div class="relative rounded-2xl overflow-hidden shadow-2xl border border-gray-700 bg-cover bg-center" style="background-image: linear-gradient(rgba(17, 24, 39, 0.85), rgba(17, 24, 39, 0.90)), url('https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=1200&q=80');">
                    <div class="px-8 py-10 text-center max-w-2xl mx-auto space-y-3">
                        <h2 class="text-2xl md:text-3xl font-bold text-red-500">📅 Agenda y Estado de Citas</h2>
                        <p class="text-gray-300 text-sm">Control detallado de pacientes por atender y atendidos en el consultorio.</p>
                    </div>
                </div>

                <div class="bg-gray-800 rounded-xl border border-gray-700 overflow-hidden shadow-xl">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="bg-gray-900 border-b border-gray-700 text-gray-400 text-sm">
                                <th class="p-4">Paciente</th>
                                <th class="p-4">Teléfono</th>
                                <th class="p-4">Diagnóstico / Motivo</th>
                                <th class="p-4">Fecha de Visita</th>
                                <th class="p-4 text-center">Estado de Atención</th>
                            </tr>
                        </thead>
                        <tbody id="tabla-agenda" class="divide-y divide-gray-700 text-gray-200">
                            <tr>
                                <td colspan="5" class="p-4 text-center text-gray-500">No hay pacientes en la agenda aún. Registra uno en el menú Pacientes.</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </section>

            <!-- PACIENTES -->
            <section id="sec-pacientes" class="seccion-contenido hidden space-y-6">
                <div class="relative rounded-2xl overflow-hidden shadow-2xl border border-gray-700 bg-cover bg-center" style="background-image: linear-gradient(rgba(17, 24, 39, 0.85), rgba(17, 24, 39, 0.90)), url('https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?auto=format&fit=crop&w=1200&q=80');">
                    <div class="px-8 py-10 flex flex-col md:flex-row justify-between items-center max-w-5xl mx-auto gap-4 text-center md:text-left">
                        <div>
                            <h2 class="text-2xl md:text-3xl font-bold text-red-500">👥 Gestión de Pacientes</h2>
                            <p class="text-gray-300 text-sm mt-1">Listado completo de expedientes e historias médicas registradas.</p>
                        </div>
                        <button onclick="abrirModalPaciente()" class="bg-red-600 hover:bg-red-500 px-5 py-3 rounded-xl font-medium text-white shadow-lg transition flex items-center gap-2 cursor-pointer">
                            <span>+ Nuevo Paciente</span>
                        </button>
                    </div>
                </div>

                <div class="bg-gray-800 rounded-xl border border-gray-700 overflow-hidden shadow-xl">
                    <table class="w-full text-left border-collapse">
                        <thead>
                            <tr class="bg-gray-900 border-b border-gray-700 text-gray-400 text-sm">
                                <th class="p-4">Nombre y Apellido</th>
                                <th class="p-4">Cédula</th>
                                <th class="p-4">Edad</th>
                                <th class="p-4">Teléfono</th>
                                <th class="p-4">Diagnóstico / Motivo</th>
                                <th class="p-4">Fecha de Visita</th>
                                <th class="p-4 text-center">Acciones</th>
                            </tr>
                        </thead>
                        <tbody id="tabla-pacientes" class="divide-y divide-gray-700 text-gray-200">
                            <tr>
                                <td colspan="7" class="p-4 text-center text-gray-500">No hay pacientes registrados aún.</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </section>

            <!-- FARMACIA -->
            <section id="sec-farmacia" class="seccion-contenido hidden space-y-6">
                <div class="relative rounded-2xl overflow-hidden shadow-2xl border border-gray-700 bg-cover bg-center" style="background-image: linear-gradient(rgba(17, 24, 39, 0.85), rgba(17, 24, 39, 0.90)), url('https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=1200&q=80');">
                    <div class="px-8 py-10 text-center max-w-2xl mx-auto space-y-3">
                        <h2 class="text-2xl md:text-3xl font-bold text-red-500">💊 Precios en Farmacias Nuevo Siglo</h2>
                        <p class="text-gray-300 text-sm">Consulta instantánea de disponibilidad y costos actualizados.</p>
                    </div>
                </div>

                <div class="bg-gray-800 p-8 rounded-xl border border-gray-700 shadow-xl max-w-3xl mx-auto">
                    <div class="flex gap-3">
                        <input type="text" id="medInput" placeholder="Ej. ibuprofeno, paracetamol, omeprazol..." class="flex-1 bg-gray-900 border border-gray-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-red-500">
                        <button onclick="buscarMedicamento()" class="bg-red-600 hover:bg-red-500 px-6 py-3 rounded-lg font-medium text-white transition cursor-pointer">Consultar</button>
                    </div>

                    <div id="resultado" class="mt-6 hidden bg-gray-900 p-5 rounded-lg border border-gray-700">
                        <p class="text-sm text-gray-400" id="resOrigen"></p>
                        <h3 class="text-lg font-bold text-white mt-1" id="resNombre"></h3>
                        <p class="text-red-400 text-xl font-semibold mt-2" id="resPrecio"></p>
                    </div>
                </div>
            </section>

            <!-- VADEMÉCUM -->
            <section id="sec-vademecum" class="seccion-contenido hidden space-y-6">
                <div class="relative rounded-2xl overflow-hidden shadow-2xl border border-gray-700 bg-cover bg-center" style="background-image: linear-gradient(rgba(17, 24, 39, 0.85), rgba(17, 24, 39, 0.90)), url('https://images.unsplash.com/photo-1471864190281-a93a3070b6de?auto=format&fit=crop&w=1200&q=80');">
                    <div class="px-8 py-10 text-center max-w-2xl mx-auto space-y-3">
                        <h2 class="text-2xl md:text-3xl font-bold text-red-500">📖 Vademécum Médico (Dosispedia Universal)</h2>
                        <p class="text-gray-300 text-sm">Base de datos clínica para consulta rápida de posología y dosis.</p>
                    </div>
                </div>

                <div class="bg-gray-800 p-8 rounded-xl border border-gray-700 space-y-6 shadow-xl max-w-4xl mx-auto">
                    <div class="flex gap-3">
                        <input type="text" id="vademecumInput" onkeydown="if(event.key==='Enter') buscarVademecum()" placeholder="Escribe cualquier medicamento..." class="flex-1 bg-gray-900 border border-gray-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-red-500">
                        <button onclick="buscarVademecum()" class="bg-red-600 hover:bg-red-500 px-6 py-3 rounded-lg font-medium text-white transition cursor-pointer">Consultar</button>
                    </div>

                    <div id="vademecum-resultado" class="hidden bg-gray-900 p-6 rounded-lg border border-gray-700 space-y-4">
                        <div class="flex justify-between items-start border-b border-gray-800 pb-3">
                            <div>
                                <h3 class="text-xl font-bold text-white" id="v-nombre"></h3>
                                <p class="text-xs text-red-400 mt-0.5" id="v-categoria"></p>
                            </div>
                            <span class="bg-gray-800 border border-gray-700 text-xs px-3 py-1 rounded-full text-gray-300" id="v-presentacion"></span>
                        </div>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div class="bg-gray-800/60 p-4 rounded-lg border border-gray-700/60">
                                <span class="text-xs font-semibold text-gray-400 uppercase tracking-wider">Dosis Mínima</span>
                                <p class="text-emerald-400 font-semibold mt-1" id="v-dosis-min"></p>
                            </div>
                            <div class="bg-gray-800/60 p-4 rounded-lg border border-gray-700/60">
                                <span class="text-xs font-semibold text-gray-400 uppercase tracking-wider">Dosis Máxima</span>
                                <p class="text-red-400 font-semibold mt-1" id="v-dosis-max"></p>
                            </div>
                        </div>

                        <div class="bg-gray-800/60 p-4 rounded-lg border border-gray-700/60">
                            <span class="text-xs font-semibold text-gray-400 uppercase tracking-wider">Indicaciones / Posología</span>
                            <p class="text-gray-200 text-sm mt-1 leading-relaxed" id="v-uso"></p>
                        </div>
                    </div>

                    <div id="vademecum-error" class="hidden bg-gray-900 p-4 rounded-lg border border-gray-700 text-center text-gray-400 text-sm">
                        Escribe el nombre de un medicamento para realizar la búsqueda.
                    </div>
                </div>
            </section>

            <!-- CONFIGURACIÓN -->
            <section id="sec-config" class="seccion-contenido hidden space-y-6">
                <div class="relative rounded-2xl overflow-hidden shadow-2xl border border-gray-700 bg-cover bg-center" style="background-image: linear-gradient(rgba(17, 24, 39, 0.85), rgba(17, 24, 39, 0.90)), url('https://images.unsplash.com/photo-1505751172876-fa1923c5c528?auto=format&fit=crop&w=1200&q=80');">
                    <div class="px-8 py-10 text-center max-w-2xl mx-auto space-y-3">
                        <h2 class="text-2xl md:text-3xl font-bold text-red-500">⚙️ Configuración de Cuenta y Red</h2>
                        <p class="text-gray-300 text-sm">Gestiona los datos de acceso al consultorio y credenciales de usuario.</p>
                    </div>
                </div>

                <div class="bg-gray-800 p-8 rounded-xl border border-gray-700 space-y-6 shadow-xl max-w-xl mx-auto">
                    <form onsubmit="guardarConfiguracion(event)" class="space-y-4">
                        <div>
                            <label class="block text-sm text-gray-300 mb-1">Nombre de la Cuenta / Consultorio</label>
                            <input type="text" id="cfg-nombre" placeholder="Ej. Dr. Juan Pérez" class="w-full bg-gray-900 border border-gray-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-red-500">
                        </div>
                        <div>
                            <label class="block text-sm text-gray-300 mb-1">Correo Electrónico</label>
                            <input type="email" id="cfg-correo" placeholder="correo@ejemplo.com" class="w-full bg-gray-900 border border-gray-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-red-500">
                        </div>
                        <div>
                            <label class="block text-sm text-gray-300 mb-1">Contraseña</label>
                            <input type="password" id="cfg-clave" placeholder="••••••••" class="w-full bg-gray-900 border border-gray-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-red-500">
                        </div>
                        <div class="pt-2">
                            <button type="submit" class="bg-red-600 hover:bg-red-500 px-6 py-2.5 rounded-lg text-white font-medium transition cursor-pointer w-full">Guardar Cambios</button>
                        </div>
                    </form>
                    <div id="cfg-alerta" class="hidden bg-emerald-900/50 border border-emerald-700 text-emerald-300 px-4 py-3 rounded-lg text-sm text-center">
                        ¡Configuración guardada exitosamente!
                    </div>
                </div>
            </section>
        </div>
    </main>

    <!-- MODAL NUEVO / EDITAR PACIENTE -->
    <div id="modal-paciente" style="display: none;" class="fixed inset-0 bg-black bg-opacity-70 z-50 items-center justify-center p-4">
        <div class="bg-gray-800 border border-gray-700 rounded-xl max-w-lg w-full p-6 space-y-4 shadow-2xl">
            <div class="flex justify-between items-center border-b border-gray-700 pb-3">
                <h3 id="modal-titulo" class="text-lg font-bold text-red-500">Registrar Nuevo Paciente</h3>
                <button onclick="cerrarModalPaciente()" class="text-gray-400 hover:text-white font-bold text-xl cursor-pointer">✕</button>
            </div>
            <form id="form-paciente" onsubmit="guardarPaciente(event)" class="space-y-4">
                <input type="hidden" id="p-index" value="-1">
                <div>
                    <label class="block text-sm text-gray-300 mb-1">Nombre Completo <span class="text-red-500">*</span></label>
                    <input type="text" id="p-nombre" required placeholder="Ej. Juan Pérez" class="w-full bg-gray-900 border border-gray-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-red-500">
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm text-gray-300 mb-1">Cédula</label>
                        <input type="text" id="p-cedula" placeholder="Opcional" class="w-full bg-gray-900 border border-gray-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-red-500">
                    </div>
                    <div>
                        <label class="block text-sm text-gray-300 mb-1">Edad</label>
                        <input type="number" id="p-edad" placeholder="Opcional" class="w-full bg-gray-900 border border-gray-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-red-500">
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-sm text-gray-300 mb-1">Teléfono</label>
                        <input type="text" id="p-telefono" placeholder="Opcional" class="w-full bg-gray-900 border border-gray-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-red-500">
                    </div>
                    <div>
                        <label class="block text-sm text-gray-300 mb-1">Fecha de Visita</label>
                        <input type="date" id="p-fecha" class="w-full bg-gray-900 border border-gray-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-red-500">
                    </div>
                </div>
                <div>
                    <label class="block text-sm text-gray-300 mb-1">Diagnóstico / Motivo</label>
                    <textarea id="p-motivo" rows="3" placeholder="Ej. Tratamiento..." class="w-full bg-gray-900 border border-gray-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-red-500"></textarea>
                </div>
                <div class="flex justify-end gap-3 pt-2">
                    <button type="button" onclick="cerrarModalPaciente()" class="bg-gray-700 hover:bg-gray-600 px-4 py-2 rounded-lg text-white text-sm cursor-pointer">Cancelar</button>
                    <button type="submit" class="bg-red-600 hover:bg-red-500 px-4 py-2 rounded-lg text-white text-sm font-medium cursor-pointer">Guardar</button>
                </div>
            </form>
        </div>
    </div>

    <!-- MODAL PERFIL -->
    <div id="modal-perfil" style="display: none;" class="fixed inset-0 bg-black bg-opacity-75 z-50 items-center justify-center p-4">
        <div class="bg-gray-800 border border-gray-700 rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl relative">
            <input type="hidden" id="pf-index" value="-1">
            <div class="h-32 bg-cover bg-center relative" style="background-image: url('https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&w=800&q=80');">
                <button onclick="cerrarModalPerfil()" class="absolute top-3 right-3 bg-black/60 hover:bg-black text-white w-8 h-8 rounded-full flex items-center justify-center font-bold text-lg transition cursor-pointer">✕</button>
            </div>
            <div class="px-6 pb-6 relative -mt-16 space-y-4">
                <div class="flex justify-between items-end">
                    <div class="w-24 h-24 bg-red-600 rounded-full border-4 border-gray-800 flex items-center justify-center text-3xl font-extrabold text-white shadow-2xl" id="pf-avatar">P</div>
                    <span class="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 text-xs px-3 py-1 rounded-full font-semibold">Paciente Registrado</span>
                </div>
                <div>
                    <h3 id="pf-nombre" class="text-2xl font-bold text-white">Nombre</h3>
                    <p id="pf-fecha" class="text-xs text-gray-400 mt-0.5">-</p>
                </div>
                <div class="grid grid-cols-3 gap-3 bg-gray-900/80 p-3 rounded-xl border border-gray-700/80 text-center">
                    <div><span class="text-xs text-gray-400 block">Cédula</span><span id="pf-cedula" class="text-sm font-semibold text-gray-200">-</span></div>
                    <div><span class="text-xs text-gray-400 block">Edad</span><span id="pf-edad" class="text-sm font-semibold text-gray-200">-</span></div>
                    <div><span class="text-xs text-gray-400 block">Teléfono</span><span id="pf-telefono" class="text-sm font-semibold text-gray-200">-</span></div>
                </div>
                <div class="space-y-2">
                    <span class="text-xs font-semibold text-red-400 uppercase tracking-wider block">Diagnóstico</span>
                    <div id="pf-motivo" class="bg-gray-900 p-4 rounded-xl border border-gray-700 text-gray-200 text-sm leading-relaxed max-h-48 overflow-y-auto">Sin diagnóstico.</div>
                </div>
                <div class="flex justify-between items-center pt-2">
                    <button type="button" onclick="eliminarPacienteDesdePerfil()" class="bg-red-600/20 hover:bg-red-600 border border-red-500/40 text-red-400 hover:text-white px-4 py-2 rounded-xl text-sm font-medium transition cursor-pointer">🗑️ Eliminar</button>
                    <button type="button" onclick="cerrarModalPerfil()" class="bg-gray-700 hover:bg-gray-600 px-6 py-2 rounded-xl text-white text-sm font-medium transition cursor-pointer">Cerrar</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        const VADEMECUM_DB = {
            "paracetamol": {nombre: "Paracetamol", categoria: "Analgésico", presentacion: "500mg", dosisMin: "500mg", dosisMax: "4g al día", uso: "Cada 6-8 horas."},
            "ibuprofeno": {nombre: "Ibuprofeno", categoria: "AINE", presentacion: "400mg", dosisMin: "400mg", dosisMax: "2.4g al día", uso: "Cada 8 horas con comida."},
            "amoxicilina": {nombre: "Amoxicilina", categoria: "Antibiótico", presentacion: "500mg", dosisMin: "500mg", dosisMax: "1g cada 8h", uso: "Por 7 días."},
            "omeprazol": {nombre: "Omeprazol", categoria: "IBP", presentacion: "20mg", dosisMin: "20mg", dosisMax: "40mg al día", uso: "En ayunas."}
        };

        function normalizar(t) { return t.toLowerCase().normalize("NFD").replace(/[\\u0300-\\u036f]/g, "").trim(); }

        function buscarVademecum() {
            const raw = document.getElementById('vademecumInput').value.trim();
            const q = normalizar(raw);
            const res = document.getElementById('vademecum-resultado');
            const err = document.getElementById('vademecum-error');
            if(!q) return;
            let found = VADEMECUM_DB[q] || {nombre: raw, categoria: "Fármaco", presentacion: "Estándar", dosisMin: "Consultar posología", dosisMax: "Según indicación", uso: "Bajo supervisión médica."};
            err.classList.add('hidden');
            res.classList.remove('hidden');
            document.getElementById('v-nombre').innerText = found.nombre;
            document.getElementById('v-categoria').innerText = found.categoria;
            document.getElementById('v-presentacion').innerText = found.presentacion;
            document.getElementById('v-dosis-min').innerText = found.dosisMin;
            document.getElementById('v-dosis-max').innerText = found.dosisMax;
            document.getElementById('v-uso').innerText = found.uso;
        }

        let listaPacientes = [];
        function cargarPacientesLocal() {
            const g = localStorage.getItem('lista_pacientes');
            if(g) { try { listaPacientes = JSON.parse(g); } catch(e){ listaPacientes = []; } }
        }
        function guardarPacientesLocal() { localStorage.setItem('lista_pacientes', JSON.stringify(listaPacientes)); }

        function abrirModalPaciente(idx = -1) {
            document.getElementById('modal-paciente').style.display = 'flex';
            if(idx > -1) {
                document.getElementById('modal-titulo').innerText = "Editar Paciente";
                document.getElementById('p-index').value = idx;
                const p = listaPacientes[idx];
                document.getElementById('p-nombre').value = p.nombre;
                document.getElementById('p-cedula').value = p.cedula === 'No especificada' ? '' : p.cedula;
                document.getElementById('p-edad').value = p.edad.replace(' años', '');
                document.getElementById('p-telefono').value = p.telefono === 'No registrado' ? '' : p.telefono;
                document.getElementById('p-fecha').value = p.fechaRaw || '';
                document.getElementById('p-motivo').value = p.motivo;
            } else {
                document.getElementById('modal-titulo').innerText = "Registrar Nuevo Paciente";
                document.getElementById('p-index').value = -1;
                document.getElementById('form-paciente').reset();
                document.getElementById('p-fecha').value = new Date().toISOString().split('T')[0];
            }
        }
        function cerrarModalPaciente() { document.getElementById('modal-paciente').style.display = 'none'; }

        function abrirModalPerfil(idx) {
            const p = listaPacientes[idx];
            document.getElementById('pf-index').value = idx;
            document.getElementById('pf-avatar').innerText = p.nombre.charAt(0).toUpperCase();
            document.getElementById('pf-nombre').innerText = p.nombre;
            document.getElementById('pf-fecha').innerText = "Visita: " + p.fecha;
            document.getElementById('pf-cedula').innerText = p.cedula;
            document.getElementById('pf-edad').innerText = p.edad;
            document.getElementById('pf-telefono').innerText = p.telefono;
            document.getElementById('pf-motivo').innerText = p.motivo;
            document.getElementById('modal-perfil').style.display = 'flex';
        }
        function cerrarModalPerfil() { document.getElementById('modal-perfil').style.display = 'none'; }

        function eliminarPacienteDesdePerfil() {
            const idx = parseInt(document.getElementById('pf-index').value);
            if(idx > -1 && confirm("¿Deseas eliminar este paciente?")) {
                listaPacientes.splice(idx, 1);
                guardarPacientesLocal();
                renderizarTodo();
                cerrarModalPerfil();
            }
        }
        function eliminarPacienteDirecto(idx) {
            if(confirm("¿Eliminar paciente?")) {
                listaPacientes.splice(idx, 1);
                guardarPacientesLocal();
                renderizarTodo();
            }
        }

        function guardarPaciente(e) {
            e.preventDefault();
            const idx = parseInt(document.getElementById('p-index').value);
            const f = document.getElementById('p-fecha').value;
            const pac = {
                nombre: document.getElementById('p-nombre').value.trim(),
                cedula: document.getElementById('p-cedula').value.trim() || 'No especificada',
                edad: document.getElementById('p-edad').value.trim() ? document.getElementById('p-edad').value + ' años' : 'S/E',
                telefono: document.getElementById('p-telefono').value.trim() || 'No registrado',
                fechaRaw: f,
                fecha: f ? new Date(f + 'T00:00:00').toLocaleDateString() : 'Sin fecha',
                motivo: document.getElementById('p-motivo').value.trim() || 'Sin diagnóstico',
                estado: idx === -1 ? 'Por atenderse' : listaPacientes[idx].estado
            };
            if(idx === -1) listaPacientes.push(pac);
            else listaPacientes[idx] = pac;
            guardarPacientesLocal();
            renderizarTodo();
            cerrarModalPaciente();
        }

        function cambiarEstadoPaciente(idx) {
            listaPacientes[idx].estado = listaPacientes[idx].estado === 'Visto' ? 'Por atenderse' : 'Visto';
            guardarPacientesLocal();
            renderizarTodo();
        }

        function renderizarTodo() {
            renderizarPacientes();
            renderizarAgenda();
            actualizarEstadisticas();
        }

        function renderizarPacientes() {
            const tb = document.getElementById('tabla-pacientes');
            if(listaPacientes.length === 0) { tb.innerHTML = `<tr><td colspan="7" class="p-4 text-center text-gray-500">No hay pacientes.</td></tr>`; return; }
            tb.innerHTML = listaPacientes.map((p, idx) => `
                <tr class="hover:bg-gray-700/50 transition">
                    <td class="p-4 font-medium cursor-pointer" onclick="abrirModalPerfil(${idx})">
                        <div class="flex items-center gap-3">
                            <div class="w-10 h-10 bg-red-600 rounded-full flex items-center justify-center text-white font-bold">${p.nombre.charAt(0)}</div>
                            <span class="text-white font-semibold">${p.nombre}</span>
                        </div>
                    </td>
                    <td class="p-4 text-gray-300">${p.cedula}</td>
                    <td class="p-4 text-gray-300">${p.edad}</td>
                    <td class="p-4 text-gray-300">${p.telefono}</td>
                    <td class="p-4 text-gray-300">${p.motivo}</td>
                    <td class="p-4 text-gray-300">${p.fecha}</td>
                    <td class="p-4 text-center space-x-2">
                        <button onclick="abrirModalPerfil(${idx})" class="px-3 py-1 bg-red-600/20 text-red-400 rounded-lg text-xs">Ver</button>
                        <button onclick="abrirModalPaciente(${idx})" class="p-1 bg-gray-700 text-gray-300 rounded-lg">✏️</button>
                        <button onclick="eliminarPacienteDirecto(${idx})" class="p-1 bg-gray-700 text-gray-300 rounded-lg">🗑️</button>
                    </td>
                </tr>
            `).join('');
        }

        function renderizarAgenda() {
            const tb = document.getElementById('tabla-agenda');
            if(listaPacientes.length === 0) { tb.innerHTML = `<tr><td colspan="5" class="p-4 text-center text-gray-500">No hay agenda.</td></tr>`; return; }
            tb.innerHTML = listaPacientes.map((p, idx) => {
                const visto = p.estado === 'Visto';
                return `
                    <tr class="hover:bg-gray-700/50 transition">
                        <td class="p-4 font-medium">${p.nombre}</td>
                        <td class="p-4 text-gray-300">${p.telefono}</td>
                        <td class="p-4 text-gray-300">${p.motivo}</td>
                        <td class="p-4 text-gray-300">${p.fecha}</td>
                        <td class="p-4 text-center">
                            <span class="px-3 py-1 rounded-full text-xs font-semibold ${visto ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'}">${p.estado}</span>
                            <button onclick="cambiarEstadoPaciente(${idx})" class="ml-2 px-3 py-1 bg-gray-700 text-white rounded-lg text-xs">Cambiar</button>
                        </td>
                    </tr>
                `;
            }).join('');
        }

        function actualizarEstadisticas() {
            document.getElementById('stat-espera').innerText = listaPacientes.filter(p => p.estado !== 'Visto').length;
            document.getElementById('stat-vistos').innerText = listaPacientes.filter(p => p.estado === 'Visto').length;
        }

        function guardarConfiguracion(e) {
            e.preventDefault();
            localStorage.setItem('cfg_nombre', document.getElementById('cfg-nombre').value);
            localStorage.setItem('cfg_correo', document.getElementById('cfg-correo').value);
            actualizarPerfilUI();
            const a = document.getElementById('cfg-alerta');
            a.classList.remove('hidden');
            setTimeout(() => a.classList.add('hidden'), 3000);
        }

        function actualizarPerfilUI() {
            const n = localStorage.getItem('cfg_nombre') || 'Admin';
            const c = localStorage.getItem('cfg_correo') || 'materytools@gmail.com';
            document.getElementById('user-display-name').innerText = n;
            document.getElementById('user-display-email').innerText = c;
            document.getElementById('user-avatar').innerText = n.charAt(0).toUpperCase();
        }

        function cerrarSesionPerfil() {
            localStorage.clear();
            actualizarPerfilUI();
            cambiarSeccion('config');
        }

        window.addEventListener('DOMContentLoaded', () => {
            cargarPacientesLocal();
            actualizarPerfilUI();
            renderizarTodo();
        });

        function toggleMobileMenu() { document.getElementById('mobile-menu').classList.toggle('hidden'); }

        function cambiarSeccion(sec) {
            document.querySelectorAll('.seccion-contenido').forEach(s => s.classList.add('hidden'));
            document.getElementById('sec-' + sec).classList.remove('hidden');
        }

        async function buscarMedicamento() {
            const med = document.getElementById('medInput').value.trim();
            if(!med) return;
            const resBox = document.getElementById('resultado');
            resBox.classList.remove('hidden');
            document.getElementById('resNombre').innerText = "Buscando...";
            try {
                const r = await fetch(`/farmacia/precio/${encodeURIComponent(med)}`);
                const d = await r.json();
                document.getElementById('resOrigen').innerText = `Origen: ${d.origen}`;
                document.getElementById('resNombre').innerText = d.medicamento_comercial;
                document.getElementById('resPrecio').innerText = d.precio_actual;
            } catch(e) {
                document.getElementById('resNombre').innerText = "Error de conexión.";
            }
        }
    </script>
</body>
</html>
"""

@app.get("/", response_class=HTMLResponse)
def leer_index():
    return HTML_CONTENT

@app.get("/farmacia/precio/{medicamento}")
def consultar_precio(medicamento: str):
    med_lower = medicamento.lower()
    precios_db = {
        "paracetamol": {"nombre": "Paracetamol 500mg (Caja x 20)", "precio": "$3.50", "origen": "Farmacias Nuevo Siglo API"},
        "ibuprofeno": {"nombre": "Ibuprofeno 400mg (Caja x 10)", "precio": "$2.80", "origen": "Farmacias Nuevo Siglo API"},
        "amoxicilina": {"nombre": "Amoxicilina 500mg (Caja x 14)", "precio": "$6.20", "origen": "Farmacias Nuevo Siglo API"},
        "omeprazol": {"nombre": "Omeprazol 20mg (Caja x 14)", "precio": "$4.00", "origen": "Farmacias Nuevo Siglo API"},
        "losartan": {"nombre": "Losartán 50mg (Caja x 15)", "precio": "$5.10", "origen": "Farmacias Nuevo Siglo API"},
    }
    
    for key in precios_db:
        if key in med_lower:
            item = precios_db[key]
            return {
                "medicamento_comercial": item["nombre"],
                "precio_actual": item["precio"],
                "origen": item["origen"]
            }
            
    return {
        "medicamento_comercial": medicamento.capitalize(),
        "precio_actual": "$4.50 (Precio Estimado)",
        "origen": "Farmacias Nuevo Siglo API (Base General)"
    }

def iniciar_servidor():
    uvicorn.run(app, host="127.0.0.1", port=8000, log_level="warning")

def main():
    t = threading.Thread(target=iniciar_servidor, daemon=True)
    t.start()

    webview.create_window('Consultorio Médico - Panel', 'http://127.0.0.1:8000', width=1200, height=800)
    webview.start()

if __name__ == '__main__':
    main()