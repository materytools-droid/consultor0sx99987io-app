@app.get("/farmacia/precio/{medicamento}")
async def obtener_precio_real(medicamento: str):
    med_prolijo = medicamento.lower().strip()
    query = med_prolijo.replace(" ", "%20")
    # Cambiamos la URL de búsqueda a Farmacias Nuevo Siglo
    url_busqueda = f"https://www.farmaciasnuevosiglo.com/search?q={query}"
    
    async with httpx.AsyncClient(follow_redirects=True) as client:
        try:
            response = await client.get(url_busqueda, headers=HEADERS, timeout=4.0)
            if response.status_code == 200:
                soup = BeautifulSoup(response.text, 'html.parser')
                # Buscamos contenedores comunes en la tienda de Nuevo Siglo
                primer_producto = soup.find("div", class_="product-item") or soup.find("div", class_="card") or soup.find("div", class_="grid-item")
                if primer_producto:
                    nombre_el = primer_producto.find(class_="product-name") or primer_producto.find("h3") or primer_producto.find("a")
                    precio_el = primer_producto.find(class_="price") or primer_producto.find(class_="money")
                    img_el = primer_producto.find("img")
                    
                    return {
                        "origen": "Farmacias Nuevo Siglo en Vivo",
                        "medicamento_comercial": nombre_el.text.strip() if nombre_el else medicamento.capitalize(),
                        "precio_actual": precio_el.text.strip() if precio_el else "Consultar en tienda",
                        "foto_url": img_el["src"] if img_el and "src" in img_el.attrs else ""
                    }
        except Exception:
            pass
            
    return {
        "origen": "Respaldo Local Nuevo Siglo",
        "medicamento_comercial": medicamento.capitalize(),
        "precio_actual": "Disponibles en sucursal",
        "foto_url": ""
    }